import java.util.Scanner;

public class khai_bao {
    public Scanner sc = new Scanner(System.in);
    private String name, gioi_tinh, ngay_sinh, dia_chi, ma_so_thue, ngay;

    public khai_bao(String name, String gioi_tinh, String ngay_sinh, String dia_chi, String ma_so_thue, String ngay) {
        this.name = name;
        this.gioi_tinh = gioi_tinh;
        this.dia_chi = dia_chi;
        this.ngay_sinh = ngay_sinh;
        this.dia_chi = dia_chi;
        this.ma_so_thue = ma_so_thue;
        this.ngay = ngay;
    }

    public void init() {
        name = sc.nextLine();
        gioi_tinh = sc.nextLine();
        ngay_sinh = sc.nextLine();
        dia_chi = sc.nextLine();
        ma_so_thue = sc.nextLine();
        ngay = sc.nextLine();
    }

    public String name() {
        return name;
    }

    public String gioi_tinh() {
        return gioi_tinh;
    }

    public String dia_chi() {
        return dia_chi;
    }

    public String ngay_sinh() {
        return ngay_sinh;
    }

    public String ma_so_thue() {
        return ma_so_thue;
    }

    public String ngay() {
        return ngay;
    }
}