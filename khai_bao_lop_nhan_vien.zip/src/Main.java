public class Main {
    public static void main(String[] args) {
        khai_bao p = new khai_bao("", "", "", "", "", "");
        p.init();
        System.out.println("00001" + " " + p.name() + " " + p.gioi_tinh() + " " + p.ngay_sinh() + " " + p.dia_chi()
                + " " + p.ma_so_thue() + " " + p.ngay());
    }
}
