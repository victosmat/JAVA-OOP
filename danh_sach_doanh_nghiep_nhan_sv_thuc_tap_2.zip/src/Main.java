import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                if (a.getQuantity() > b.getQuantity())
                    return -1;
                else if (a.getQuantity() == b.getQuantity() && a.getMa().compareTo(b.getMa()) < 0)
                    return -1;
                return 1;
            }
        });
        t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            int a = sc.nextInt(), b = sc.nextInt();
            System.out.println("DANH SACH DOANH NGHIEP NHAN TU " + a + " DEN " + b + " SINH VIEN:");
            for (khai_bao x : arr)
                if (x.getQuantity() >= a && x.getQuantity() <= b)
                    System.out.println(x.toString());
        }
        sc.close();
    }
}
