public class khai_bao {
    private String msv, name, lop;
    private float a, b, c;

    public khai_bao(String msv, String name, String lop, float a, float b, float c) {
        this.name = name;
        this.msv = msv;
        this.lop = lop;
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public String getMsv() {
        return msv;
    }

    public String toString() {
        return msv + " " + name + " " + lop + " " + String.format("%.1f", a) + " " + String.format("%.1f", b) + " "
                + String.format("%.1f", c);
    }
}
