public class khai_bao {
    int id;
    private String name;
    private int so_luong, don_gia;

    public khai_bao(String name, int so_luong, int don_gia) {
        this.name = name;
        this.so_luong = so_luong;
        this.don_gia = don_gia;
    }

    public int chiet_khau() {
        int ans = 0;
        if (so_luong > 10)
            ans = 5;
        else if (so_luong >= 8 && so_luong <= 10)
            ans = 2;
        else if (so_luong >= 5 && so_luong < 8)
            ans = 1;
        return so_luong * don_gia * ans / 100;
    }

    public int thanh_tien() {
        return (so_luong * don_gia) - chiet_khau();
    }

    public String ma_hang() {
        String s[] = name.toUpperCase().split("\\s+");
        String ans = "";
        for (int i = 0; i < 2; i++)
            ans += s[i].charAt(0);
        ans += '0';
        return ans;
    }

    public String toString() {
        return ma_hang() + id + " " + name + " " + chiet_khau() + " " + thanh_tien();
    }
}
