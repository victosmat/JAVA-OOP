import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = Integer.parseInt(sc.nextLine());
        for (int i = 1; i <= t; i++) {
            String name = sc.nextLine();
            String code = sc.nextLine();
            String date = sc.nextLine();
            float GPA = Float.parseFloat(sc.nextLine());
            String GPA1 = String.format("%.2f", GPA);

            SinhVien sv = new SinhVien(name, code, chuan_hoa(date).toString(), GPA1);
            if (i < 10) {
                String ok = "0" + String.valueOf(i);
                sv.Id = ok;
            } else {
                String ok = String.valueOf(i);
                sv.Id = ok;
            }
            System.out.println(sv);
        }
    }

    public static StringBuffer chuan_hoa(String s) {
        String ans[] = s.split("/");
        StringBuffer str = new StringBuffer();
        for (int i = 0; i < ans.length; i++) {
            if (ans[i].length() == 1)
                str.append('0' + ans[i]);
            else
                str.append(ans[i]);
            if (i < ans.length - 1)
                str.append('/');
        }
        return str;
    }
}