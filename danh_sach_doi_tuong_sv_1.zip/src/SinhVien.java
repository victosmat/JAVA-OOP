class SinhVien {
    String Id;
    private String name;
    private String code;
    public String date;
    private String GPA;

    public SinhVien(String name, String code, String date, String gPA) {

        this.name = name;
        this.code = code;
        this.date = date;
        this.GPA = gPA;
    }

    @Override
    public String toString() {
        return "B20DCCN0" + Id + " " + name + " " + code + " " + date + " " + GPA;
    }

}