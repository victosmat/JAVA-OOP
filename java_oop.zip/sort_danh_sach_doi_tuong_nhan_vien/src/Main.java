import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        List<khai_bao> arr = new ArrayList<>();
        sc.nextLine();
        for (int i = 1; i <= t; i++) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(),
                    sc.nextLine());
            p.id = Integer.toString(i);
            if (p.id.length() < 2)
                p.id = '0' + p.id;
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                String s1[] = a.getNgay_sinh().split("/");
                String s2[] = b.getNgay_sinh().split("/");
                if (Integer.parseInt(s1[2]) > Integer.parseInt(s2[2]))
                    return 1;
                else if (Integer.parseInt(s1[2]) == Integer.parseInt(s2[2])
                        && Integer.parseInt(s1[1]) > Integer.parseInt(s2[1]))
                    return 1;
                else if (Integer.parseInt(s1[2]) == Integer.parseInt(s2[2])
                        && Integer.parseInt(s1[1]) == Integer.parseInt(s2[1])
                        && Integer.parseInt(s1[0]) > Integer.parseInt(s2[0]))
                    return 1;
                return -1;
            }
        });
        for (khai_bao x : arr) {
            System.out.println(x.toString());
        }
    }
}
