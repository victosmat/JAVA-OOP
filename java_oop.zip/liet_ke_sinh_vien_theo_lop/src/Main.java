import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(p);
        }
        int test = sc.nextInt();
        sc.nextLine();
        while (test-- > 0) {
            String s = sc.nextLine();
            System.out.println(("DANH SACH SINH VIEN LOP " + s + ":"));
            for (khai_bao x : arr)
                if (x.getLop().equals(s))
                    System.out.println(x.toString());
        }
    }
}
