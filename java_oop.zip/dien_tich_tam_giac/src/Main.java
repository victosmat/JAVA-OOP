import java.util.Scanner;
import java.lang.Math;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        while (t-- > 0) {
            canh p1 = new canh(sc.nextDouble(), sc.nextDouble());
            canh p2 = new canh(sc.nextDouble(), sc.nextDouble());
            canh p3 = new canh(sc.nextDouble(), sc.nextDouble());
            Double a = p1.khoang_cach(p2);
            Double b = p1.khoang_cach(p3);
            Double c = p2.khoang_cach(p3);
            if (a + b > c && a + c > b && b + c > a) {
                Double kq = (double) 0.25 * (double) Math.sqrt((a + b + c) * (a + b - c) * (-a + b + c) * (a - b + c));
                Long ans = Math.round(kq * 100);
                System.out.printf("%.2f", (double) ans / 100);
                System.out.println();
            } else
                System.out.println("INVALID");
        }
    }
}
