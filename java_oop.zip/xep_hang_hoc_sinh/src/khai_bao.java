public class khai_bao {
    String id;
    private String name;
    private float point;

    public khai_bao(String name, float point) {
        this.name = name;
        this.point = point;
    }

    public String rank() {
        if (point < 5)
            return "Yeu";
        else if (point >= 5 && point < 7)
            return "Trung Binh";
        else if (point >= 7 && point < 9)
            return "Kha";
        return "Gioi";
    }

    public float getPoint() {
        return point;
    }

    public String toString() {
        return "HS" + id + " " + name + " " + point + " " + rank();
    }
}
