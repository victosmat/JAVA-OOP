import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        List<Float> Point = new ArrayList<>();
        Map<Float, Integer> stt = new LinkedHashMap<>();
        int t = sc.nextInt();
        sc.nextLine();
        for (int i = 1; i <= t; i++) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextFloat());
            sc.nextLine();
            p.id = String.valueOf(i);
            if (i < 10)
                p.id = '0' + p.id;
            Point.add(p.getPoint());
            arr.add(p);
        }
        Point.sort(Comparator.reverseOrder());
        for (int i = 0; i < Point.size(); i++) {
            if (!stt.containsKey(Point.get(i)))
                stt.put(Point.get(i), i + 1);
        }
        for (khai_bao x : arr)
            System.out.println(x.toString() + " " + stt.get(x.getPoint()));
    }
}
