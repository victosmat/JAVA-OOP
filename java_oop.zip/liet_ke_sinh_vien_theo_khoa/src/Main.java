import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static List<khai_bao> arr = new ArrayList<>();
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(p);
        }
        int test = sc.nextInt();
        sc.nextLine();
        while (test-- > 0) {
            String s = sc.nextLine();
            System.out.println("DANH SACH SINH VIEN KHOA " + s + ":");
            for (khai_bao x : arr)
                if (s.equals(x.getKhoa()))
                    System.out.println(x.toString());
        }
    }
}