import java.util.Scanner;

public class PhanSo {
    private long tu, mau;
    public Scanner sc = new Scanner(System.in);

    public PhanSo(long tu, long mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public void init() {
        tu = sc.nextLong();
        mau = sc.nextLong();
    }

    public void rut_gon() {
        long tmp = gcd(tu, mau);
        tu /= tmp;
        mau /= tmp;
    }

    public long gcd(long a, long b) {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

    public void cong(PhanSo p) {
        long ts = tu * p.mau + p.tu * mau;
        long ms = mau * p.mau;
        PhanSo kq = new PhanSo(ts, ms);
        kq.rut_gon();
        System.out.println(kq.toString());
    }

    public String toString() {
        return tu + "/" + mau;
    }
}