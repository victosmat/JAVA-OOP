import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        String s[] = sc.nextLine().split("\\s+");
        PhanSo p1 = new PhanSo(Integer.parseInt(s[0]), Integer.parseInt(s[1]));
        PhanSo p2 = new PhanSo(Integer.parseInt(s[2]), Integer.parseInt(s[3]));
        p1.rut_gon();
        p2.rut_gon();
        p1.cong(p2);
    }

}