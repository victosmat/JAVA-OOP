import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        List<khai_bao> arr = new ArrayList<>();
        sc.nextLine();
        for (int i = 1; i <= t; i++) {
            String name = sc.nextLine(), nganh = sc.nextLine();
            String id = Integer.toString(i);
            if (id.length() < 2)
                id = '0' + id;
            khai_bao p = new khai_bao(id, name, nganh);
            arr.add(p);
        }
        t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            String s = sc.next();
            System.out.println("DANH SACH GIANG VIEN THEO TU KHOA " + s + ":");
            s = s.toLowerCase();
            for (khai_bao x : arr)
                if (x.getName().toLowerCase().contains(s))
                    System.out.println(x.toString());
        }
    }
}
