class khai_bao {
    String id;
    private String ma;
    private int cs_cu, cs_moi;

    public khai_bao(String ma, int cs_cu, int cs_moi) {
        this.ma = ma;
        this.cs_cu = cs_cu;
        this.cs_moi = cs_moi;
    }

    public int he_so() {
        if (ma.equals("KD"))
            return 3;
        else if (ma.equals("NN"))
            return 5;
        else if (ma.equals("TT"))
            return 4;
        return 2;
    }

    public int thanh_tien() {
        return (cs_moi - cs_cu) * he_so() * 550;
    }

    public int phu_troi() {
        int ans = cs_moi - cs_cu;
        if (ans < 50)
            return 0;
        else if (ans >= 50 && ans <= 100)
            return (int) (Math.round(thanh_tien() * 1.0 * 35 / 100) / 1.0);
        return thanh_tien();
    }

    public int tong_tien() {
        return phu_troi() + thanh_tien();
    }

    public String toString() {
        return "KH" + id + " " + he_so() + " " + thanh_tien() + " " + phu_troi() + " " + tong_tien();
    }
}