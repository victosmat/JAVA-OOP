public class Point3D {
    private int x, y, z;

    public Point3D(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public int getx() {
        return x;
    }

    public int gety() {
        return y;
    }

    public int getz() {
        return z;
    }

    public static boolean check(Point3D a, Point3D b, Point3D c, Point3D d) {
        Point3D vt1 = new Point3D(b.getx() - a.getx(), b.gety() - a.gety(), b.getz() - a.getz());
        Point3D vt2 = new Point3D(c.getx() - a.getx(), c.gety() - a.gety(), c.getz() - a.getz());
        Point3D vt3 = new Point3D(d.getx() - a.getx(), d.gety() - a.gety(), d.getz() - a.getz());
        Point3D vt = new Point3D(vt1.getz() * vt2.gety() - vt1.gety() * vt2.getz(),
                vt1.getx() * vt2.getz() - vt1.getz() * vt2.getx(), vt1.gety() * vt2.getx() - vt1.getx() * vt2.gety());
        double check = vt3.getx() * vt.getx() + vt3.gety() * vt.gety() + vt3.getz() * vt.getz();
        if (check == 0)
            return true;
        return false;
    }
}
