import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static List<khai_bao> arr = new ArrayList<>();
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(p);
        }
        int test = sc.nextInt();
        sc.nextLine();
        while (test-- > 0) {
            String str = sc.nextLine().toUpperCase();
            String s[] = str.split(" ");
            Character ans = s[0].charAt(0);
            System.out.println("DANH SACH SINH VIEN NGANH " + str + ":");
            if (ans == 'C' || ans == 'A') {
                for (khai_bao x : arr)
                    if (ans == x.getKhoa() && x.getLop() != 'E')
                        System.out.println(x.toString());
            } else
                for (khai_bao x : arr)
                    if (ans == x.getKhoa())
                        System.out.println(x.toString());
        }
    }
}