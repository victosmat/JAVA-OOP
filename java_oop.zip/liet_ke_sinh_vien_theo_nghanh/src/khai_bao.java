public class khai_bao {
    private String msv, name, lop, email;

    public khai_bao(String msv, String name, String lop, String email) {
        this.msv = msv;
        this.name = name;
        this.lop = lop;
        this.email = email;
    }

    public char getKhoa() {
        return msv.charAt(5);
    }

    public char getLop() {
        return lop.charAt(0);
    }

    public String toString() {
        return msv + " " + name + " " + lop + " " + email;
    }
}
