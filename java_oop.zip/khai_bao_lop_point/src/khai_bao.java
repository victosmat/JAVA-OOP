import java.lang.Math;

public class khai_bao {
    private double x, y;

    public khai_bao(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public void khoang_cach(khai_bao p) {
        double canh1 = Math.abs(p.x - x);
        double canh2 = Math.abs(p.y - y);
        double kq = Math.sqrt(Math.pow(canh1, 2) + Math.pow(canh2, 2));
        System.out.printf("%.4f", kq);
    }
}
