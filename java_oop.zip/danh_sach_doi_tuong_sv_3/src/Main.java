import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = Integer.parseInt(sc.nextLine());
        List<khai_bao> arr = new ArrayList<>();
        for (int i = 1; i <= t; i++) {
            String name = sc.nextLine();
            String lop = sc.nextLine().toUpperCase();
            String ngay_sinh = sc.nextLine();
            float gpa = Float.parseFloat(sc.nextLine());
            String gpa1 = String.format("%.2f", gpa);
            khai_bao sv = new khai_bao(chuan_hoa_name(name), lop, chuan_hoa_ngay(ngay_sinh), gpa1);
            String stt = "";
            if (i < 10)
                stt = "0" + String.valueOf(i);
            else
                stt = String.valueOf(i);
            sv.id = stt;
            arr.add(sv);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                return Float.parseFloat(a.getGPA()) < Float.parseFloat(b.getGPA()) ? 1 : -1;
            }
        });
        for (khai_bao x : arr) {
            System.out.println(x.toString());
        }
    }

    public static String chuan_hoa_ngay(String s) {
        String ans[] = s.split("/");
        String str = "";
        for (int i = 0; i < ans.length; i++) {
            if (ans[i].length() == 1)
                str += '0' + ans[i];
            else
                str += ans[i];
            if (i < ans.length - 1)
                str += '/';
        }
        return str;
    }

    public static String chuan_hoa_name(String s) {
        String str[] = s.trim().toLowerCase().split("\\s+");
        String ans = "";
        for (int i = 0; i < str.length; i++)
            ans += String.valueOf(str[i].charAt(0)).toUpperCase() + str[i].substring(1) + " ";
        return ans;
    }
}
