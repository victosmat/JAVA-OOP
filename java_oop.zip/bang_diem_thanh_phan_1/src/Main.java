import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextFloat(), sc.nextFloat(),
                    sc.nextFloat());
            sc.nextLine();
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                return (a.getMsv().compareTo(b.getMsv()) < 0) ? -1 : 1;
            }
        });
        int count = 1;
        for (khai_bao x : arr) {
            System.out.println(count + " " + x.toString());
            count += 1;
        }
        sc.close();
    }
}
