import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        for (int i = 1; i <= t; i++) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextInt(), sc.nextInt());
            sc.nextLine();
            p.id = String.valueOf(i);
            if (i < 10)
                p.id = '0' + p.id;
            arr.add(p);
        }
        for (khai_bao x : arr)
            System.out.println(x.toString());
    }
}
