public class khai_bao {
    String id;
    private String name, chuc_vu;
    private int luong, so_ngay;

    public khai_bao(String name, String chuc_vu, int luong, int so_ngay) {
        this.name = name;
        this.chuc_vu = chuc_vu;
        this.luong = luong;
        this.so_ngay = so_ngay;
    }

    public int phu_cap() {
        if (chuc_vu.equals("GD"))
            return 500;
        else if (chuc_vu.equals("PGD"))
            return 400;
        else if (chuc_vu.equals("TP"))
            return 300;
        else if (chuc_vu.equals("KT"))
            return 250;
        return 100;
    }

    public int luong_cb() {
        return luong * so_ngay;
    }

    public int tam_ung() {
        double ans = (phu_cap() + luong_cb()) * 2 / 3;
        ans = Math.round(ans / 1000) * 1000;
        if (ans < 25000)
            return (int) ans;
        return 25000;
    }

    public String toString() {
        return "NV" + id + " " + name + " " + phu_cap() + " " + luong_cb() + " " + tam_ung() + " "
                + (luong_cb() + phu_cap() - tam_ung());
    }
}
