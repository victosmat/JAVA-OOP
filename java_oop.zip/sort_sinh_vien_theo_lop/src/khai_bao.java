public class khai_bao {
    private String msv, name, lop, email;

    public khai_bao(String msv, String name, String lop, String email) {
        this.msv = msv;
        this.name = name;
        this.lop = lop;
        this.email = email;
    }

    public String getMsv() {
        return msv;
    }

    public String getLop() {
        return lop;
    }

    public String toString() {
        return msv + " " + name + " " + lop + " " + email;
    }
}
