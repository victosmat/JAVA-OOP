import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextLong(), sc.nextLong());
            sc.nextLine();
            arr.add(p);
        }
        for (khai_bao x : arr)
            System.out.println(x.toString());
    }
}
