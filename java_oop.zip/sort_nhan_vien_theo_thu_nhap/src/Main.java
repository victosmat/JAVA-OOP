import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        for (int i = 1; i <= t; i++) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLine(), sc.nextInt(), sc.nextInt());
            sc.nextLine();
            p.id = String.valueOf(i);
            if (i < 10)
                p.id = '0' + p.id;
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                if (a.luong_chinh() > b.luong_chinh())
                    return -1;
                else if (a.luong_chinh() == b.luong_chinh() && a.id.compareTo(b.id) < 0)
                    return -1;
                return 1;
            }
        });
        for (khai_bao x : arr)
            System.out.println(x.toString());
    }
}
