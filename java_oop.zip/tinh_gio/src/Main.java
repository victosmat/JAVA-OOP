
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);
    public static List<tinh_gio> arr = new ArrayList<tinh_gio>();

    public static void main(String[] args) {
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            tinh_gio p = new tinh_gio(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<tinh_gio>() {
            public int compare(tinh_gio a, tinh_gio b) {
                return (a.thoi_gian() < b.thoi_gian()) ? 1 : -1;
            }
        });
        for (tinh_gio x : arr) {
            System.out.println(x.toString());
        }
    }
}
