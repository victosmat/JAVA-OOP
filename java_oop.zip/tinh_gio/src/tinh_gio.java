public class tinh_gio {
    int gio, phut;
    private String ma, name, gio_vao, gio_ra;

    public tinh_gio(String ma, String name, String gio_vao, String gio_ra) {
        this.ma = ma;
        this.name = name;
        this.gio_vao = gio_vao;
        this.gio_ra = gio_ra;
    }

    public int thoi_gian() {
        String s1[] = gio_vao.split(":");
        int a = Integer.parseInt(s1[0]);
        int b = Integer.parseInt(s1[1]);
        String s2[] = gio_ra.split(":");
        int c = Integer.parseInt(s2[0]);
        int d = Integer.parseInt(s2[1]);
        int ans = 0;
        if (d < b)
            ans = (c - 1 - a) * 60 + (d + 60 - b);
        else
            ans = (c - a) * 60 + (d - b);
        return ans;
    }

    public String toString() {
        gio = thoi_gian() / 60;
        phut = thoi_gian() % 60;
        return ma + " " + name + " " + gio + " gio " + phut + " phut";
    }
}
