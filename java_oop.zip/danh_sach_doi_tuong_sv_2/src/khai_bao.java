class khai_bao {
    String id;
    private String name;
    private String lop;
    public String ngay_sinh;
    private String gpa;

    public khai_bao(String name, String lop, String ngay_sinh, String gpa) {

        this.name = name;
        this.lop = lop;
        this.ngay_sinh = ngay_sinh;
        this.gpa = gpa;
    }

    @Override
    public String toString() {
        return "B20DCCN0" + id + " " + name + lop + " " + ngay_sinh + " " + gpa;
    }
}