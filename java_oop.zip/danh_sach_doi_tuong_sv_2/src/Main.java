import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = Integer.parseInt(sc.nextLine());
        for (int i = 1; i <= t; i++) {
            String name = sc.nextLine();
            String lop = sc.nextLine().toUpperCase();
            String ngay_sinh = sc.nextLine();
            float gpa = Float.parseFloat(sc.nextLine());
            String gpa1 = String.format("%.2f", gpa);
            khai_bao sv = new khai_bao(chuan_hoa_name(name), lop, chuan_hoa_ngay(ngay_sinh), gpa1);
            String stt = "";
            if (i < 10)
                stt = "0" + String.valueOf(i);
            else
                stt = String.valueOf(i);
            sv.id = stt;
            System.out.println(sv);
        }
    }

    public static String chuan_hoa_ngay(String s) {
        String ans[] = s.split("/");
        String str = "";
        for (int i = 0; i < ans.length; i++) {
            if (ans[i].length() == 1)
                str += '0' + ans[i];
            else
                str += ans[i];
            if (i < ans.length - 1)
                str += '/';
        }
        return str;
    }

    public static String chuan_hoa_name(String s) {
        String str[] = s.trim().toLowerCase().split("\\s+");
        String ans = "";
        for (int i = 0; i < str.length; i++)
            ans += String.valueOf(str[i].charAt(0)).toUpperCase() + str[i].substring(1) + " ";
        return ans;
    }
}
