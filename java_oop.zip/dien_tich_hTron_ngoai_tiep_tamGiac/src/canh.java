public class canh {
    private double x, y;

    public canh(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double khoang_cach(canh p) {
        double canh1 = Math.abs(p.x - x);
        double canh2 = Math.abs(p.y - y);
        double kq = Math.sqrt(Math.pow(canh1, 2) + Math.pow(canh2, 2));
        return kq;
    }
}
