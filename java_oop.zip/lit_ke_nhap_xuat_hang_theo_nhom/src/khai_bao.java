class khai_bao {
    private String name;
    private long so_luong;

    public khai_bao(String name, Long so_luong) {
        this.name = name;
        this.so_luong = so_luong;
    }

    public char getName() {
        return name.charAt(0);
    }

    public long xuat() {
        if (name.charAt(0) == 'A')
            return (long) (Math.round((so_luong * (1.0f) * 60 / 100) / 1.0)) * 1;
        return Math.round(so_luong * 70 / 100);
    }

    public long don_gia() {
        if (name.charAt(name.length() - 1) == 'Y')
            return 110000;
        return 135000;
    }

    public long tien() {
        return xuat() * don_gia();
    }

    public long thue() {
        long ans = 22;
        if (name.charAt(0) == 'A' && name.charAt(name.length() - 1) == 'Y')
            ans = 8;
        else if (name.charAt(0) == 'A' && name.charAt(name.length() - 1) == 'N')
            ans = 11;
        else if (name.charAt(0) == 'B' && name.charAt(name.length() - 1) == 'Y')
            ans = 17;
        return tien() * ans / 100;
    }

    public String toString() {
        return name + " " + so_luong + " " + xuat() + " " + don_gia() + " " + tien() + " " + thue();
    }
}