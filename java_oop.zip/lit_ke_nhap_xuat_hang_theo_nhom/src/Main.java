import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextLong());
            sc.nextLine();
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                return (a.thue() > b.thue()) ? -1 : 1;
            }
        });
        String s = sc.nextLine();
        for (khai_bao x : arr)
            if (x.getName() == s.charAt(0))
                System.out.println(x.toString());
    }
}
