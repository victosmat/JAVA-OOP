public class Main {
    public static void main(String[] args) {
        khai_bao p = new khai_bao("", "", "", (double) 1.0);
        p.init();
        System.out.print(
                "B" + p.msv().substring(1, 3) + "DCCN001 " + p.name() + " " + p.msv() + " " + p.nam_sinh() + " ");
        System.out.printf("%.2f", p.point());
    }
}
