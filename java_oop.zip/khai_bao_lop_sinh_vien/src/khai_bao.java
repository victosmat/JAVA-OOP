import java.util.Scanner;

public class khai_bao {
    public Scanner sc = new Scanner(System.in);
    private String name, msv, nam_sinh;
    private double point;

    public khai_bao(String name, String nam_sinh, String msv, double point) {
        this.name = name;
        this.nam_sinh = nam_sinh;
        this.msv = msv;
        this.point = point;
    }

    public void init() {
        name = sc.nextLine();
        msv = sc.next();
        nam_sinh = sc.next();
        String s[] = nam_sinh.split("/");
        nam_sinh = "";
        for (int i = 0; i < s.length; i++) {
            if (s[i].length() == 1)
                nam_sinh += '0' + s[i];
            else
                nam_sinh += s[i];
            if (i < s.length - 1)
                nam_sinh += '/';
        }
        point = sc.nextDouble();
    }

    public String name() {
        return name;
    }

    public String msv() {
        return msv;
    }

    public String nam_sinh() {
        return nam_sinh;
    }

    public double point() {
        return point;
    }
}