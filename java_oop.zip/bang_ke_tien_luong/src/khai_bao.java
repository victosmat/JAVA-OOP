class khai_bao {
    String id;
    private String name, chuc_vu;
    private long luong_ngay, so_ngay;

    public khai_bao(String name, long luong_ngay, long so_ngay, String chuc_vu) {
        this.name = name;
        this.luong_ngay = luong_ngay;
        this.so_ngay = so_ngay;
        this.chuc_vu = chuc_vu;
    }

    public long luong_thang() {
        return luong_ngay * so_ngay;
    }

    public long thuong() {
        if (so_ngay >= 25)
            return luong_thang() * 20 / 100;
        else if (so_ngay >= 22)
            return luong_thang() * 10 / 100;
        return 0;
    }

    public long phu_cap() {
        if (chuc_vu.equals("GD"))
            return 250000;
        else if (chuc_vu.equals("PGD"))
            return 200000;
        else if (chuc_vu.equals("TP"))
            return 180000;
        return 150000;
    }

    public long tong_tien() {
        return luong_thang() + thuong() + phu_cap();
    }

    public String toString() {
        return "NV" + id + " " + name + " " + luong_thang() + " " + thuong() + " " + phu_cap() + " " + tong_tien();
    }
}