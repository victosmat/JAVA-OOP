public class Main {

    public static void main(String[] args) {
        solve p = new solve("", "", (float) 1.0, (float) 1.0, (float) 1.0);
        p.nhap();



        
        System.out.println(p.s1() + " " + p.s2() + " " + p.Tong_diem());
    }
}
