
import java.util.Scanner;

public class solve {
    private String s1, s2;
    private float a, b, c;

    public solve(String s1, String s2, float a, float b, float c) {
        this.s1 = s1;
        this.s2 = s2;
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public void nhap() {
        Scanner sc = new Scanner(System.in);
        s1 = sc.nextLine();
        s2 = sc.nextLine();
        a = sc.nextFloat();
        b = sc.nextFloat();
        c = sc.nextFloat();
        sc.close();
    }

    public String s1() {
        return s1;
    }

    public String s2() {
        return s2;
    }

    public float Tong_diem() {
        return (a + b + c);
    }
}
