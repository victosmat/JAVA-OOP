public class khai_bao {
    private String id, name, nganh;

    public khai_bao(String id, String name, String nganh) {
        this.id = id;
        this.name = name;
        this.nganh = nganh;
    }

    public String getName() {
        String s[] = name.split(" ");
        return s[s.length - 1];
    }

    public String getId() {
        return id;
    }

    public String toString() {
        String s[] = nganh.toUpperCase().split(" ");
        String ans = "";
        for (String x : s)
            ans += x.charAt(0);
        return "GV" + id + " " + name + " " + ans;
    }
}
