import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        List<khai_bao> arr = new ArrayList<>();
        sc.nextLine();
        for (int i = 1; i <= t; i++) {
            String name = sc.nextLine(), nganh = sc.nextLine();
            String id = Integer.toString(i);
            if (id.length() < 2)
                id = '0' + id;
            khai_bao p = new khai_bao(id, name, nganh);
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao a, khai_bao b) {
                if (a.getName().compareTo(b.getName()) < 0)
                    return -1;
                else if (a.getName().compareTo(b.getName()) == 0 && a.getId().compareTo(b.getId()) < 0)
                    return -1;
                return 1;
            }
        });
        for (khai_bao x : arr) {
            System.out.println(x.toString());
        }
    }
}
