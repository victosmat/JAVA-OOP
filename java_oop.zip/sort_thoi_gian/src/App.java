import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class App {
    public static Scanner sc = new Scanner(System.in);
    public static List<thoi_gian> arr = new ArrayList<>();

    public static void main(String[] args) {
        int t = sc.nextInt();
        while (t-- > 0) {
            thoi_gian tg = new thoi_gian(sc.nextInt(), sc.nextInt(), sc.nextInt());
            arr.add(tg);
        }
        Collections.sort(arr, new Comparator<thoi_gian>() {
            public int compare(thoi_gian a, thoi_gian b) {
                if (a.gio() > b.gio())
                    return 1;
                else if (a.gio() == b.gio() && a.phut() > b.phut())
                    return 1;
                else if (a.gio() == b.gio() && a.phut() == b.phut() && a.giay() > b.giay())
                    return 1;
                return -1;
            }
        });
        for (thoi_gian x : arr)
            System.out.println(x.toString());
    }
}
