import java.util.Scanner;

public class thoi_gian {
    private int gio, phut, giay;
    public static Scanner sc = new Scanner(System.in);

    public thoi_gian(int gio, int phut, int giay) {
        this.gio = gio;
        this.phut = phut;
        this.giay = giay;
    }

    public int gio() {
        return gio;
    }

    public int phut() {
        return phut;
    }

    public int giay() {
        return giay;
    }

    public String toString() {
        return gio + " " + phut + " " + giay;
    }
}