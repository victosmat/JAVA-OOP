class khai_bao {
    private String name, ma;
    private long don_gia, so_luong;

    public khai_bao(String name, String ma, long don_gia, long so_luong) {
        this.name = name;
        this.ma = ma;
        this.don_gia = don_gia;
        this.so_luong = so_luong;
    }

    public String stt() {
        return ma.substring(1, 4);
    }

    public long giam_gia() {
        if (ma.charAt(ma.length() - 1) == '1')
            return don_gia * so_luong * 50 / 100;
        return don_gia * so_luong * 30 / 100;
    }

    public long thanh_tien() {
        return so_luong * don_gia - giam_gia();
    }

    public String toString() {
        return name + " " + ma + " " + stt() + " " + giam_gia() + " " + thanh_tien();
    }
}