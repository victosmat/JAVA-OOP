public class MyMain {
    public static void main(String[] args) {
        phan_so p = new phan_so(1, 1);
        p.init();
        p.rut_gon();
        System.out.println(p.toString());
    }
}
