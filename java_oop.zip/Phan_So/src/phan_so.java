import java.util.Scanner;

public class phan_so {
    Scanner sc = new Scanner(System.in);
    private long tu, mau;

    public phan_so(long tu, long mau) {
        this.tu = tu;
        this.mau = mau;
    }

    public void init() {
        tu = sc.nextLong();
        mau = sc.nextLong();
    }

    public long gcd(long a, long b) {
        if (b == 0)
            return a;
        return gcd(b, a % b);
    }

    public void rut_gon() {
        long tmp = gcd(tu, mau);
        tu /= tmp;
        mau /= tmp;
    }

    public String toString() {
        return tu + "/" + mau;
    }
}
