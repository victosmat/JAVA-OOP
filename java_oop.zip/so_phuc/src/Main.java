import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao a = new khai_bao(sc.nextInt(), sc.nextInt());
            khai_bao b = new khai_bao(sc.nextInt(), sc.nextInt());
            khai_bao ans = new khai_bao(a.getPhan_thuc() + b.getPhan_thuc(), a.getPhan_ao() + b.getPhan_ao());
            khai_bao c = new khai_bao(ans.getPhan_thuc() * a.getPhan_thuc() - ans.getPhan_ao() * a.getPhan_ao(),
                    ans.getPhan_thuc() * a.getPhan_ao() + ans.getPhan_ao() * a.getPhan_thuc());
            khai_bao d = new khai_bao(ans.getPhan_thuc() * ans.getPhan_thuc() - ans.getPhan_ao() * ans.getPhan_ao(),
                    2 * ans.getPhan_ao() * ans.getPhan_thuc());
            System.out.println(c.toString() + ", " + d.toString());
        }
    }
}
