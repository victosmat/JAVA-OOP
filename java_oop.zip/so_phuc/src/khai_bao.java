public class khai_bao {
    private int phan_thuc, phan_ao;

    public khai_bao(int phan_thuc, int phan_ao) {
        this.phan_thuc = phan_thuc;
        this.phan_ao = phan_ao;
    }

    public int getPhan_thuc() {
        return phan_thuc;
    }

    public int getPhan_ao() {
        return phan_ao;
    }

    public String toString() {
        if (phan_ao < 0) {
            phan_ao *= -1;
            return phan_thuc + " - " + phan_ao + "i";
        }
        return phan_thuc + " + " + phan_ao + "i";
    }
}
