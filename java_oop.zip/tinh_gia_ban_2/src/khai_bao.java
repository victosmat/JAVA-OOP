public class khai_bao {
    String id;
    public String ten_hang, don_vi;
    public int don_gia_nhap, so_luong;

    public khai_bao(String ten_hang, String don_vi, int don_gia_nhap, int so_luong) {
        this.ten_hang = ten_hang;
        this.don_vi = don_vi;
        this.don_gia_nhap = don_gia_nhap;
        this.so_luong = so_luong;
    }

    public int phi_van_chuyen() {
        int phi = don_gia_nhap * so_luong;
        return (int) Math.round((phi * 0.05));
    }

    public int thanh_tien() {
        return phi_van_chuyen() + don_gia_nhap * so_luong;

    }

    public int gia_ban() {
        return (int) Math.ceil(thanh_tien() * 1.02 / so_luong / 100) * 100;
    }

    public String toString() {
        return "MH" + id + " " + ten_hang + " " + don_vi + " " + phi_van_chuyen() + " " + thanh_tien() + " "
                + gia_ban();
    }
}