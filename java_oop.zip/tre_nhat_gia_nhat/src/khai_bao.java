
class khai_bao {
    private String name, ngay_sinh;

    public khai_bao(String name, String ngay_sinh) {
        this.name = name;
        this.ngay_sinh = ngay_sinh;
    }

    public String getNgaySinh() {
        return ngay_sinh;
    }

    public String toString() {
        return name;
    }
}