import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<khai_bao> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.next(), sc.next());
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<khai_bao>() {
            public int compare(khai_bao p1, khai_bao p2) {
                String a[] = p1.getNgaySinh().split("/");
                String b[] = p2.getNgaySinh().split("/");
                if (a[2].compareTo(b[2]) > 0)
                    return -1;
                else if (a[2].compareTo(b[2]) == 0 && a[1].compareTo(b[1]) > 0)
                    return -1;
                else if (a[2].compareTo(b[2]) == 0 && a[1].compareTo(b[1]) == 0 && a[0].compareTo(b[0]) > 0)
                    return -1;
                return 1;
            }
        });
        System.out.println(arr.get(0).toString() + "\n" + arr.get(arr.size() - 1));
        sc.close();
    }
}
