
import java.util.Scanner;

public class khai_bao {
    private int width, hight;
    private String color;

    public khai_bao(int width, int hight, String color) {
        this.width = width;
        this.hight = hight;
        this.color = color;
    }

    public void init() {
        Scanner sc = new Scanner(System.in);
        String s[] = sc.nextLine().split("\\s+");
        width = Integer.parseInt(s[0]);
        hight = Integer.parseInt(s[1]);
        color = String.valueOf(s[2].charAt(0)).toUpperCase() + s[2].substring(1).toLowerCase();
        sc.close();
    }

    public int a() {
        return width;
    }

    public int b() {
        return hight;
    }

    public int chu_vi() {
        return (width + hight) * 2;
    }

    public int dien_tich() {
        return width * hight;
    }

    public String Color() {
        return color;
    }
}
