public class Main {
    public static void main(String[] args) {
        khai_bao p = new khai_bao(1, 1, "");
        p.init();
        if (p.a() < 1 || p.b() < 1) {
            System.out.println("INVALID");
            return;
        }
        System.out.println(p.chu_vi() + " " + p.dien_tich() + " " + p.Color());
    }
}
