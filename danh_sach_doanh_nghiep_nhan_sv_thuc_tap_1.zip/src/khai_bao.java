class khai_bao {
    private String ma, name, quantity;

    public khai_bao(String ma, String name, String quantity) {
        this.ma = ma;
        this.name = name;
        this.quantity = quantity;
    }

    public String getMa() {
        return ma;
    }

    public int getQuantity() {
        return Integer.parseInt(quantity);
    }

    public String toString() {
        return ma + " " + name + " " + quantity;
    }
}