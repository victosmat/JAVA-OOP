public class khai_bao {
    String id;
    private String name, gioi_tinh, ngay_sinh, dia_chi, ma, ngay_ky;

    public khai_bao(String name, String gioi_tinh, String ngay_sinh, String dia_chi, String ma, String ngay_ky) {
        this.name = name;
        this.gioi_tinh = gioi_tinh;
        this.ngay_sinh = ngay_sinh;
        this.dia_chi = dia_chi;
        this.ma = ma;
        this.ngay_ky = ngay_ky;
    }

    public String toString() {
        return "000" + id + " " + name + " " + gioi_tinh + " " + ngay_sinh + " " + dia_chi + " " + ma + " " + ngay_ky;
    }
}
