
class khai_bao {
    int id;
    private String name, msv, lop, email, doanh_nghiep;

    public khai_bao(String msv, String name, String lop, String email, String doanh_nghiep) {
        this.msv = msv;
        this.name = name;
        this.lop = lop;
        this.email = email;
        this.doanh_nghiep = doanh_nghiep;
    }

    public String getMsv() {
        return msv;
    }

    public String getDoanhNghiep() {
        return doanh_nghiep;
    }

    public String toString() {
        return id + " " + msv + " " + name + " " + lop + " " + email + " " + doanh_nghiep;
    }
}