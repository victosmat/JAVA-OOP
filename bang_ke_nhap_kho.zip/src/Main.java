import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<khai_bao> arr = new ArrayList<>();
        Map<String, Integer> m = new LinkedHashMap<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            khai_bao p = new khai_bao(sc.nextLine(), sc.nextInt(), sc.nextInt());
            sc.nextLine();
            if (m.containsKey(p.ma_hang())) {
                p.id = m.get(p.ma_hang()) + 1;
                m.replace(p.ma_hang(), p.id);
            } else {
                m.put(p.ma_hang(), 1);
                p.id = 1;
            }
            arr.add(p);
        }
        for (khai_bao x : arr)
            System.out.println(x.toString());
    }
}
