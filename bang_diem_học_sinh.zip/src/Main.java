import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<in_diem> arr = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        for (int stt = 1; stt <= t; stt++) {
            String name = sc.nextLine();
            double point = 0;
            for (int i = 0; i < 10; i++) {
                double x = sc.nextDouble();
                if (i == 0 || i == 1)
                    point += x * 2;
                else
                    point += x;
            }
            sc.nextLine();
            point /= 12;
            point = (double) Math.round(point * 10) / 10;
            String id;
            if (stt < 10)
                id = "0" + String.valueOf(stt);
            else
                id = String.valueOf(stt);
            in_diem p = new in_diem(id, name, point, check(point));
            arr.add(p);
        }
        Collections.sort(arr, new Comparator<in_diem>() {
            public int compare(in_diem a, in_diem b) {
                if (a.getPoint() > b.getPoint())
                    return -1;
                else if (a.getPoint() == b.getPoint() && a.getId() < b.getId())
                    return -1;
                return 1;
            }
        });
        for (in_diem x : arr) {
            System.out.println(x.toString());
        }
    }

    public static String check(Double a) {
        if (a >= 9)
            return "XUAT SAC";
        else if (a >= 8)
            return "GIOI";
        else if (a >= 7)
            return "KHA";
        else if (a >= 5)
            return "TB";
        return "YEU";
    }
}
