public class in_diem {
    private String id, name, rank;
    private Double point;

    public in_diem(String id, String name, double point, String rank) {
        this.id = id;
        this.name = name;
        this.point = point;
        this.rank = rank;
    }

    public int getId() {
        return Integer.parseInt(id);
    }

    public Double getPoint() {
        return point;
    }

    public String toString() {
        return "HS" + id + " " + name + " " + point + " " + rank;
    }
}
