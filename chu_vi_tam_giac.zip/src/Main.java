import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int t = sc.nextInt();
        while (t-- > 0) {
            chu_vi p1 = new chu_vi(sc.nextDouble(), sc.nextDouble());
            chu_vi p2 = new chu_vi(sc.nextDouble(), sc.nextDouble());
            chu_vi p3 = new chu_vi(sc.nextDouble(), sc.nextDouble());
            Double a = p1.khoang_cach(p2);
            Double b = p1.khoang_cach(p3);
            Double c = p2.khoang_cach(p3);
            if (a + b > c && a + c > b && b + c > a)
                System.out.printf("%.3f\n", a + b + c);
            else
                System.out.println("INVALID");
        }
    }
}
