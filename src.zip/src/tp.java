public class tp {
    private String ma, name, gia_cuoc;

    public tp(String ma, String name, String gia_cuoc) {
        this.ma = ma;
        this.name = name;
        this.gia_cuoc = gia_cuoc;
    }

    public String getMa() {
        return ma;
    }

    public String getName() {
        return name;
    }

    public String getGia_cuoc() {
        return gia_cuoc;
    }
}
