public class cuoc_goi {
    String so_thue_bao, begin, end;

    public cuoc_goi(String so_thue_bao, String begin, String end) {
        this.so_thue_bao = so_thue_bao;
        this.begin = begin;
        this.end = end;
    }

    public String getSo_thue_bao() {
        return so_thue_bao;
    }

    public String getMa() {
        if (so_thue_bao.charAt(0) != '0')
            return so_thue_bao.substring(1, 3);
        return "0";
    }

    public String getBegin() {
        return begin;
    }

    public String getEnd() {
        return end;
    }
}
