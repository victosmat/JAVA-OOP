import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static Scanner sc = new Scanner(System.in);

    public static long tong_phut(String begin, String end) throws ParseException {
        SimpleDateFormat date = new SimpleDateFormat("hh:mm");
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(date.parse(begin));
        c2.setTime(date.parse(end));
        return (c2.getTime().getTime() - c1.getTime().getTime()) / (60 * 1000);
    }

    public static void main(String[] args) throws ParseException {
        List<tp> tp_obj = new ArrayList<>();
        List<cuoc_goi> cuoc_goi_obj = new ArrayList<>();
        int t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            tp p = new tp(sc.nextLine(), sc.nextLine(), sc.nextLine());
            sc.nextLine();
            tp_obj.add(p);
        }
        t = sc.nextInt();
        sc.nextLine();
        while (t-- > 0) {
            cuoc_goi p = new cuoc_goi(sc.nextLine(), sc.nextLine(), sc.nextLine());
            cuoc_goi_obj.add(p);
        }
        for (cuoc_goi x : cuoc_goi_obj) {
            double ans = tong_phut(x.getBegin(), x.getEnd());
            String check = "";
            if (x.getMa().equals("0")) {
                ans = Math.ceil(ans / 3.00);
                check = "Noi mang";
            }
            for (tp y : tp_obj)
                if (y.getMa().equals(x.getMa())) {
                    if (check.equals(""))
                        System.out.println(x.getSo_thue_bao() + " " + y.getName() + " " + ans + " "
                                + ans * Integer.parseInt(y.getGia_cuoc()));
                    else
                        System.out.println(x.getSo_thue_bao() + " " + check + " " + ans + " "
                                + ans * Integer.parseInt(y.getGia_cuoc()));
                }
        }
    }
}
